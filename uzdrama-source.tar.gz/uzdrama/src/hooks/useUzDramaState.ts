import { useState, useEffect, useCallback } from "react";
import type { Drama, Review, WatchEntry } from "../types";
import { storage } from "../data/storage";

export function useUzDramaState() {
  const [dramas, setDramasState] = useState<Drama[]>(() => storage.loadDramas());
  const [favorites, setFavorites] = useState<Set<number>>(
    () => new Set(storage.loadFavs())
  );
  const [reviews, setReviews] = useState<Review[]>(() => storage.loadReviews());
  const [history, setHistory] = useState<WatchEntry[]>(() =>
    storage.loadHistory()
  );
  const [profile, setProfile] = useState(() => storage.loadProfile());

  const setDramas = useCallback((next: Drama[]) => {
    setDramasState(next);
    storage.saveDramas(next);
  }, []);

  useEffect(() => {
    storage.saveFavs(Array.from(favorites));
  }, [favorites]);

  useEffect(() => {
    storage.saveReviews(reviews);
  }, [reviews]);

  useEffect(() => {
    storage.saveHistory(history);
  }, [history]);

  useEffect(() => {
    storage.saveProfile(profile);
  }, [profile]);

  const toggleFav = useCallback((id: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const addReview = useCallback(
    (dramaId: number, rating: number, text: string) => {
      const review: Review = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        dramaId,
        user: profile.name,
        rating,
        text,
        createdAt: Date.now(),
      };
      setReviews((prev) => [review, ...prev]);
    },
    [profile.name]
  );

  const deleteReview = useCallback((id: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const recordWatch = useCallback(
    (dramaId: number, episode: number, progress: number) => {
      setHistory((prev) => {
        const filtered = prev.filter((h) => h.dramaId !== dramaId);
        return [
          { dramaId, episode, progress, updatedAt: Date.now() },
          ...filtered,
        ].slice(0, 50);
      });
      setDramasState((prev) => {
        const updated = prev.map((d) =>
          d.id === dramaId ? { ...d, views: (d.views || 0) + (progress === 0 ? 1 : 0) } : d
        );
        if (progress === 0) storage.saveDramas(updated);
        return updated;
      });
    },
    []
  );

  const clearHistory = useCallback(() => {
    if (confirm("Tarixni butunlay tozalashni xohlaysizmi?")) {
      setHistory([]);
    }
  }, []);

  return {
    dramas,
    setDramas,
    favorites,
    toggleFav,
    reviews,
    addReview,
    deleteReview,
    history,
    recordWatch,
    clearHistory,
    profile,
    setProfile,
  };
}
