import { useState, useMemo } from "react";
import type { Drama, Review } from "../types";
import {
  StarIcon,
  PlayIcon,
  HeartIcon,
  ChevronLeftIcon,
} from "../components/Icons";
import { Row } from "../components/Row";
import { VideoPlayer } from "../components/VideoPlayer";
import { ReviewSection } from "../components/ReviewSection";

export function DramaDetailPage({
  drama,
  onBack,
  favorites,
  toggleFav,
  onSelect,
  related,
  reviews,
  currentUser,
  onAddReview,
  onDeleteReview,
  onWatch,
}: {
  drama: Drama;
  onBack: () => void;
  favorites: Set<number>;
  toggleFav: (id: number) => void;
  onSelect: (d: Drama) => void;
  related: Drama[];
  reviews: Review[];
  currentUser: string;
  onAddReview: (rating: number, text: string) => void;
  onDeleteReview: (id: string) => void;
  onWatch: (episode: number, progress: number) => void;
}) {
  const [activeTab, setActiveTab] = useState<"qismlar" | "haqida" | "izohlar">(
    "qismlar"
  );
  const [playingEp, setPlayingEp] = useState<number | null>(null);
  const isFav = favorites.has(drama.id);

  const episodes = useMemo(
    () =>
      Array.from({ length: drama.episodes }, (_, i) => ({
        number: i + 1,
        title: `${
          drama.episodes === 1 ? "Toʻliq film" : `${i + 1}-qism`
        }`,
        duration: drama.category === "film" ? "2s 12d" : "1s 05d",
        released: `${drama.year}-yil`,
      })),
    [drama]
  );

  const startWatch = (ep: number) => {
    setPlayingEp(ep);
    onWatch(ep, 0);
  };

  return (
    <div className="fade-in">
      <div
        className={`relative h-[42vh] min-h-[320px] w-full bg-gradient-to-br ${drama.backdrop}`}
      >
        {drama.posterUrl && (
          <img
            src={drama.posterUrl}
            alt={drama.title}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(222_47%_6%)] to-transparent" />
        <button
          onClick={onBack}
          className="absolute top-4 left-4 bg-black/50 backdrop-blur-md p-2 rounded-full hover:bg-black/70 z-10"
        >
          <ChevronLeftIcon className="w-6 h-6 text-white" />
        </button>
      </div>
      <div className="container mx-auto px-4 sm:px-8 -mt-32 relative z-10">
        <div className="flex flex-col sm:flex-row gap-6 mb-8">
          <div
            className={`w-40 sm:w-56 aspect-[2/3] rounded-xl overflow-hidden bg-gradient-to-br ${drama.poster} shadow-2xl flex-shrink-0 mx-auto sm:mx-0 relative ring-1 ring-white/10`}
          >
            {drama.posterUrl && (
              <img
                src={drama.posterUrl}
                alt={drama.title}
                className="absolute inset-0 w-full h-full object-cover"
              />
            )}
            <div className="absolute inset-0 bg-black/20" />
          </div>
          <div className="flex-1 pt-2 sm:pt-12">
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-1">
              {drama.title}
            </h1>
            <p className="text-white/60 text-sm mb-3">{drama.originalTitle}</p>
            <div className="flex flex-wrap items-center gap-3 mb-4 text-sm">
              <div className="flex items-center gap-1 bg-yellow-500/20 px-2 py-1 rounded">
                <StarIcon className="w-4 h-4 text-yellow-400" />
                <span className="font-bold text-yellow-400">
                  {drama.rating}
                </span>
              </div>
              <span className="text-white/70">{drama.year}</span>
              <span className="text-white/70">{drama.country}</span>
              <span
                className={`px-2 py-1 rounded text-xs font-bold ${
                  drama.status === "Davom etmoqda"
                    ? "bg-green-500/20 text-green-400"
                    : "bg-gray-500/20 text-gray-300"
                }`}
              >
                {drama.status}
              </span>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {drama.genre.map((g) => (
                <span
                  key={g}
                  className="bg-white/10 backdrop-blur text-white text-xs px-3 py-1 rounded-full"
                >
                  {g}
                </span>
              ))}
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => startWatch(1)}
                className="bg-purple-600 text-white font-bold px-6 py-2.5 rounded-lg flex items-center gap-2 hover:bg-purple-700 transition-colors shadow-lg shadow-purple-600/30"
              >
                <PlayIcon className="w-5 h-5" />
                Koʻrishni boshlash
              </button>
              <button
                onClick={() => toggleFav(drama.id)}
                className={`font-bold px-6 py-2.5 rounded-lg flex items-center gap-2 transition-colors ${
                  isFav
                    ? "bg-rose-600 text-white"
                    : "bg-white/10 text-white hover:bg-white/20"
                }`}
              >
                <HeartIcon filled={isFav} className="w-5 h-5" />
                {isFav ? "Saqlangan" : "Saqlash"}
              </button>
            </div>
          </div>
        </div>

        <div className="flex border-b border-white/10 mb-6 overflow-x-auto scrollbar-hide">
          {(["qismlar", "haqida", "izohlar"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 sm:px-6 py-3 font-bold capitalize whitespace-nowrap transition-colors ${
                activeTab === tab
                  ? "text-purple-400 border-b-2 border-purple-400"
                  : "text-white/60 hover:text-white"
              }`}
            >
              {tab === "izohlar" ? `Izohlar (${reviews.length})` : tab}
            </button>
          ))}
        </div>

        {activeTab === "qismlar" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-12">
            {episodes.slice(0, 24).map((ep) => (
              <div
                key={ep.number}
                onClick={() => startWatch(ep.number)}
                className="bg-white/5 hover:bg-white/10 rounded-lg p-4 cursor-pointer transition-colors group flex items-center gap-4"
              >
                <div
                  className={`w-16 h-16 rounded-lg bg-gradient-to-br ${drama.poster} flex items-center justify-center flex-shrink-0 relative`}
                >
                  <PlayIcon className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="text-white font-bold absolute group-hover:opacity-0 transition-opacity">
                    {ep.number}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold">{ep.title}</h4>
                  <p className="text-white/60 text-sm">
                    {ep.duration} • {ep.released}
                  </p>
                </div>
              </div>
            ))}
            {drama.episodes > 24 && (
              <div className="col-span-full text-center text-white/60 py-4">
                Yana {drama.episodes - 24} ta qism mavjud
              </div>
            )}
          </div>
        )}

        {activeTab === "haqida" && (
          <div className="max-w-3xl mb-12 space-y-6">
            <div>
              <h3 className="text-white font-bold text-lg mb-2">Tafsilot</h3>
              <p className="text-white/80 leading-relaxed">
                {drama.description}
              </p>
            </div>
            <div>
              <h3 className="text-white font-bold text-lg mb-2">Aktyorlar</h3>
              <div className="flex flex-wrap gap-2">
                {drama.cast.map((c) => (
                  <span
                    key={c}
                    className="bg-white/10 text-white px-3 py-1.5 rounded-lg text-sm"
                  >
                    {c}
                  </span>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <Detail label="Rejissor" value={drama.director} />
              <Detail label="Davlat" value={drama.country} />
              <Detail label="Yil" value={String(drama.year)} />
              <Detail label="Qismlar" value={String(drama.episodes)} />
              <Detail label="Reyting" value={`${drama.rating}/10`} />
              <Detail label="Holat" value={drama.status} />
            </div>
          </div>
        )}

        {activeTab === "izohlar" && (
          <ReviewSection
            reviews={reviews}
            currentUser={currentUser}
            onAdd={onAddReview}
            onDelete={onDeleteReview}
          />
        )}
      </div>

      {related.length > 0 && (
        <Row
          title="Oʻxshash kontent"
          dramas={related}
          onSelect={onSelect}
          favorites={favorites}
          toggleFav={toggleFav}
        />
      )}

      {playingEp !== null && (
        <VideoPlayer
          drama={drama}
          episode={playingEp}
          onClose={() => setPlayingEp(null)}
          onProgress={(p) => onWatch(playingEp, p)}
        />
      )}
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-white/50 text-xs uppercase">{label}</p>
      <p className="text-white font-bold">{value}</p>
    </div>
  );
}
