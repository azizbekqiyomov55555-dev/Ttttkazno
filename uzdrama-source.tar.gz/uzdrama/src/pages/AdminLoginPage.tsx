import { useState } from "react";
import { ADMIN_PASSWORD } from "../types";

export function AdminLoginPage({
  onLogin,
  onCancel,
}: {
  onLogin: () => void;
  onCancel: () => void;
}) {
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pw === ADMIN_PASSWORD) {
      onLogin();
    } else {
      setError("Notoʻgʻri parol");
    }
  };

  return (
    <div className="container mx-auto px-4 py-20 fade-in flex items-center justify-center">
      <form
        onSubmit={submit}
        className="w-full max-w-md bg-white/5 border border-white/10 rounded-xl p-8 shadow-2xl"
      >
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4 shadow-xl shadow-purple-500/30">
            <span className="text-white font-black text-2xl">U</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-white/60 text-sm mt-1">
            Kirish uchun parolni kiriting
          </p>
        </div>
        <input
          type="password"
          autoFocus
          value={pw}
          onChange={(e) => {
            setPw(e.target.value);
            setError("");
          }}
          placeholder="Parol"
          className="w-full bg-white/10 text-white px-4 py-3 rounded-lg border border-white/20 focus:outline-none focus:border-purple-500 mb-3"
        />
        {error && <p className="text-rose-400 text-sm mb-3">{error}</p>}
        <button
          type="submit"
          className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg mb-2 shadow-lg shadow-purple-600/30"
        >
          Kirish
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="w-full text-white/60 hover:text-white text-sm py-2"
        >
          Orqaga
        </button>
        <p className="text-white/30 text-xs text-center mt-4">
          Demo parol: admin123
        </p>
      </form>
    </div>
  );
}
