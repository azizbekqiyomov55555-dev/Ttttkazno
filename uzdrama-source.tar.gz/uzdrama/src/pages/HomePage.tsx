import type { Drama, WatchEntry } from "../types";
import { HeroBanner } from "../components/HeroBanner";
import { Row } from "../components/Row";
import { FireIcon, ClockIcon } from "../components/Icons";

export function HomePage({
  dramas,
  history,
  favorites,
  toggleFav,
  onSelect,
}: {
  dramas: Drama[];
  history: WatchEntry[];
  favorites: Set<number>;
  toggleFav: (id: number) => void;
  onSelect: (d: Drama) => void;
}) {
  const featured = dramas.filter((d) => d.featured);
  const heroDrama =
    featured[Math.floor(Date.now() / 10000) % Math.max(1, featured.length)] ||
    dramas[0];

  if (!heroDrama) return null;

  const trending = [...dramas]
    .sort((a, b) => (b.views || 0) - (a.views || 0))
    .slice(0, 10);
  const top10 = [...dramas].sort((a, b) => b.rating - a.rating).slice(0, 10);
  const newReleases = dramas.filter((d) => d.year >= 2023);
  const koreanDramas = dramas.filter(
    (d) => d.country === "Koreya" && d.category === "drama"
  );
  const films = dramas.filter((d) => d.category === "film");
  const animes = dramas.filter((d) => d.category === "anime");
  const shoular = dramas.filter((d) => d.category === "shou");

  const continueDramas = history
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .map((h) => dramas.find((d) => d.id === h.dramaId))
    .filter((d): d is Drama => !!d)
    .slice(0, 10);

  return (
    <>
      <HeroBanner
        drama={heroDrama}
        onPlay={() => onSelect(heroDrama)}
        onInfo={() => onSelect(heroDrama)}
      />
      {continueDramas.length > 0 && (
        <Row
          title="Davom etish"
          icon={<ClockIcon className="w-5 h-5 text-purple-400" />}
          dramas={continueDramas}
          onSelect={onSelect}
          favorites={favorites}
          toggleFav={toggleFav}
        />
      )}
      <Row
        title="Trendda"
        icon={<FireIcon className="w-5 h-5 text-orange-400" />}
        dramas={trending}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
      <Row
        title="Bugungi TOP 10"
        dramas={top10}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
        ranked
      />
      <Row
        title="Yangi qoʻshilganlar"
        dramas={newReleases}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
      <Row
        title="Koreys dramalari"
        dramas={koreanDramas}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
      <Row
        title="Filmlar"
        dramas={films}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
      <Row
        title="Anime"
        dramas={animes}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
      <Row
        title="Shoular"
        dramas={shoular}
        onSelect={onSelect}
        favorites={favorites}
        toggleFav={toggleFav}
      />
    </>
  );
}
