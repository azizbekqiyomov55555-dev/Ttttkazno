import { useState, useRef } from "react";
import type { Drama } from "../types";
import { POSTER_GRADIENTS } from "../types";
import { CloseIcon, DownloadIcon, UploadIcon } from "../components/Icons";
import { exportAll, importAll } from "../data/storage";

type EmptyDraft = Omit<Drama, "id">;
const EMPTY_DRAFT: EmptyDraft = {
  title: "",
  originalTitle: "",
  year: new Date().getFullYear(),
  country: "Koreya",
  genre: [],
  rating: 0,
  episodes: 1,
  status: "Tugagan",
  description: "",
  cast: [],
  director: "",
  poster: POSTER_GRADIENTS[0],
  backdrop: POSTER_GRADIENTS[0],
  category: "drama",
  featured: false,
  videoUrl: "",
  posterUrl: "",
};

export function AdminPage({
  dramas,
  setDramas,
  onExit,
}: {
  dramas: Drama[];
  setDramas: (d: Drama[]) => void;
  onExit: () => void;
}) {
  const [editing, setEditing] = useState<Drama | null>(null);
  const [draft, setDraft] = useState<EmptyDraft>(EMPTY_DRAFT);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const filtered = dramas.filter(
    (d) =>
      d.title.toLowerCase().includes(filter.toLowerCase()) ||
      d.originalTitle.toLowerCase().includes(filter.toLowerCase())
  );

  const startNew = () => {
    setEditing(null);
    setDraft({
      ...EMPTY_DRAFT,
      poster:
        POSTER_GRADIENTS[
          Math.floor(Math.random() * POSTER_GRADIENTS.length)
        ],
    });
    setShowForm(true);
  };

  const startEdit = (d: Drama) => {
    setEditing(d);
    setDraft({ ...d });
    setShowForm(true);
  };

  const save = () => {
    if (!draft.title.trim()) {
      alert("Sarlavha kiritilishi shart");
      return;
    }
    const finalDraft = { ...draft, backdrop: draft.poster };
    if (editing) {
      setDramas(
        dramas.map((d) =>
          d.id === editing.id ? { ...finalDraft, id: editing.id } : d
        )
      );
    } else {
      const newId = Math.max(0, ...dramas.map((d) => d.id)) + 1;
      setDramas([{ ...finalDraft, id: newId }, ...dramas]);
    }
    setShowForm(false);
    setEditing(null);
  };

  const remove = (id: number) => {
    if (confirm("Rostdan ham oʻchirmoqchimisiz?")) {
      setDramas(dramas.filter((d) => d.id !== id));
    }
  };

  const doExport = () => {
    const data = exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `uzdrama-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const doImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result));
        if (!confirm(`Joriy maʼlumotlar almashtiriladi. Davom etilsinmi?`))
          return;
        importAll(data);
        location.reload();
      } catch {
        alert("Faylni oʻqib boʻlmadi");
      }
    };
    reader.readAsText(file);
  };

  const stats = {
    total: dramas.length,
    withVideo: dramas.filter((d) => d.videoUrl).length,
    withPoster: dramas.filter((d) => d.posterUrl).length,
    featured: dramas.filter((d) => d.featured).length,
  };

  return (
    <div className="container mx-auto px-4 sm:px-8 py-8 fade-in">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-white">
            Admin Panel
          </h1>
          <p className="text-white/60 text-sm mt-1">
            Kontentni boshqarish — {dramas.length} ta element
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={startNew}
            className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-4 py-2 rounded-lg shadow-lg shadow-purple-600/30"
          >
            + Yangi qoʻshish
          </button>
          <button
            onClick={doExport}
            className="bg-white/10 hover:bg-white/20 text-white font-bold px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <DownloadIcon className="w-4 h-4" /> Eksport
          </button>
          <button
            onClick={() => fileRef.current?.click()}
            className="bg-white/10 hover:bg-white/20 text-white font-bold px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <UploadIcon className="w-4 h-4" /> Import
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            onChange={doImport}
            className="hidden"
          />
          <button
            onClick={onExit}
            className="bg-white/10 hover:bg-white/20 text-white font-bold px-4 py-2 rounded-lg"
          >
            Chiqish
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <Stat label="Jami" value={stats.total} accent="purple" />
        <Stat label="Video bilan" value={stats.withVideo} accent="green" />
        <Stat label="Poster bilan" value={stats.withPoster} accent="blue" />
        <Stat label="Bannerda" value={stats.featured} accent="rose" />
      </div>

      <input
        type="text"
        placeholder="Sarlavha boʻyicha qidirish..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:outline-none focus:border-purple-500 mb-6"
      />

      <div className="bg-white/5 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-white/5 text-white/60 text-xs uppercase">
              <tr>
                <th className="px-4 py-3">Poster</th>
                <th className="px-4 py-3">Sarlavha</th>
                <th className="px-4 py-3 hidden sm:table-cell">Kategoriya</th>
                <th className="px-4 py-3 hidden md:table-cell">Yil</th>
                <th className="px-4 py-3 hidden md:table-cell">Reyting</th>
                <th className="px-4 py-3 hidden lg:table-cell">Video</th>
                <th className="px-4 py-3 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((d) => (
                <tr
                  key={d.id}
                  className="border-t border-white/5 hover:bg-white/5"
                >
                  <td className="px-4 py-3">
                    <div
                      className={`w-10 h-14 rounded bg-gradient-to-br ${d.poster} relative overflow-hidden`}
                    >
                      {d.posterUrl && (
                        <img
                          src={d.posterUrl}
                          alt=""
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-white font-bold">{d.title}</div>
                    <div className="text-white/50 text-xs">
                      {d.originalTitle}
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="bg-purple-500/20 text-purple-300 px-2 py-1 rounded text-xs">
                      {d.category}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-white/80">
                    {d.year}
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-yellow-400 font-bold">
                    {d.rating}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {d.videoUrl ? (
                      <span className="text-green-400 text-xs">✓ Bor</span>
                    ) : (
                      <span className="text-white/30 text-xs">Yoʻq</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <button
                      onClick={() => startEdit(d)}
                      className="text-purple-400 hover:text-purple-300 mr-3 text-sm font-bold"
                    >
                      Tahrirlash
                    </button>
                    <button
                      onClick={() => remove(d.id)}
                      className="text-rose-400 hover:text-rose-300 text-sm font-bold"
                    >
                      Oʻchirish
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={7}
                    className="px-4 py-12 text-center text-white/50"
                  >
                    Hech narsa yoʻq
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 overflow-y-auto p-4"
          onClick={() => setShowForm(false)}
        >
          <div
            className="max-w-2xl mx-auto bg-[hsl(222_47%_9%)] border border-white/10 rounded-xl p-6 my-8 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                {editing ? "Tahrirlash" : "Yangi kontent"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="bg-white/10 p-2 rounded-lg hover:bg-white/20"
              >
                <CloseIcon className="w-5 h-5 text-white" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Sarlavha (oʻzbek)">
                  <input
                    value={draft.title}
                    onChange={(e) =>
                      setDraft({ ...draft, title: e.target.value })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Asl nomi">
                  <input
                    value={draft.originalTitle}
                    onChange={(e) =>
                      setDraft({ ...draft, originalTitle: e.target.value })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Yil">
                  <input
                    type="number"
                    value={draft.year}
                    onChange={(e) =>
                      setDraft({ ...draft, year: Number(e.target.value) })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Davlat">
                  <input
                    value={draft.country}
                    onChange={(e) =>
                      setDraft({ ...draft, country: e.target.value })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Reyting (0-10)">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    value={draft.rating}
                    onChange={(e) =>
                      setDraft({ ...draft, rating: Number(e.target.value) })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Qismlar soni">
                  <input
                    type="number"
                    min="1"
                    value={draft.episodes}
                    onChange={(e) =>
                      setDraft({ ...draft, episodes: Number(e.target.value) })
                    }
                    className="form-input"
                  />
                </Field>
                <Field label="Kategoriya">
                  <select
                    value={draft.category}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        category: e.target.value as Drama["category"],
                      })
                    }
                    className="form-input"
                  >
                    <option value="drama">Drama</option>
                    <option value="film">Film</option>
                    <option value="anime">Anime</option>
                    <option value="shou">Shou</option>
                  </select>
                </Field>
                <Field label="Holat">
                  <select
                    value={draft.status}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        status: e.target.value as Drama["status"],
                      })
                    }
                    className="form-input"
                  >
                    <option value="Tugagan">Tugagan</option>
                    <option value="Davom etmoqda">Davom etmoqda</option>
                  </select>
                </Field>
              </div>

              <Field label="Janrlar (vergul bilan ajrating)">
                <input
                  value={draft.genre.join(", ")}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      genre: e.target.value
                        .split(",")
                        .map((s) => s.trim())
                        .filter(Boolean),
                    })
                  }
                  placeholder="Romantik, Drama, Triller"
                  className="form-input"
                />
              </Field>

              <Field label="Aktyorlar (vergul bilan ajrating)">
                <input
                  value={draft.cast.join(", ")}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      cast: e.target.value
                        .split(",")
                        .map((s) => s.trim())
                        .filter(Boolean),
                    })
                  }
                  className="form-input"
                />
              </Field>

              <Field label="Rejissor">
                <input
                  value={draft.director}
                  onChange={(e) =>
                    setDraft({ ...draft, director: e.target.value })
                  }
                  className="form-input"
                />
              </Field>

              <Field label="Tafsilot">
                <textarea
                  value={draft.description}
                  onChange={(e) =>
                    setDraft({ ...draft, description: e.target.value })
                  }
                  rows={4}
                  className="form-input"
                />
              </Field>

              <Field label="Video havolasi (.mp4 yoki .webm URL)">
                <input
                  value={draft.videoUrl || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, videoUrl: e.target.value })
                  }
                  placeholder="https://example.com/video.mp4"
                  className="form-input"
                />
              </Field>

              <Field label="Poster rasm havolasi (URL)">
                <input
                  value={draft.posterUrl || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, posterUrl: e.target.value })
                  }
                  placeholder="https://example.com/poster.jpg"
                  className="form-input"
                />
              </Field>

              <Field label="Poster rangi (agar rasm boʻlmasa)">
                <div className="grid grid-cols-6 gap-2">
                  {POSTER_GRADIENTS.map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() =>
                        setDraft({ ...draft, poster: g, backdrop: g })
                      }
                      className={`aspect-square rounded-lg bg-gradient-to-br ${g} ${
                        draft.poster === g ? "ring-2 ring-white" : ""
                      }`}
                    />
                  ))}
                </div>
              </Field>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={!!draft.featured}
                  onChange={(e) =>
                    setDraft({ ...draft, featured: e.target.checked })
                  }
                  className="w-4 h-4"
                />
                Bosh sahifa banneriga chiqarilsin
              </label>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={save}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg shadow-lg shadow-purple-600/30"
                >
                  Saqlash
                </button>
                <button
                  onClick={() => setShowForm(false)}
                  className="bg-white/10 hover:bg-white/20 text-white font-bold py-3 px-6 rounded-lg"
                >
                  Bekor qilish
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent: "purple" | "green" | "blue" | "rose";
}) {
  const colors: Record<string, string> = {
    purple: "from-purple-500/20 to-purple-500/5 border-purple-500/30",
    green: "from-green-500/20 to-green-500/5 border-green-500/30",
    blue: "from-blue-500/20 to-blue-500/5 border-blue-500/30",
    rose: "from-rose-500/20 to-rose-500/5 border-rose-500/30",
  };
  return (
    <div
      className={`bg-gradient-to-br ${colors[accent]} border rounded-xl p-4`}
    >
      <div className="text-white/60 text-xs uppercase font-bold">{label}</div>
      <div className="text-white text-3xl font-black mt-1">{value}</div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-white/70 text-sm font-bold mb-1.5 block">
        {label}
      </span>
      {children}
    </label>
  );
}
