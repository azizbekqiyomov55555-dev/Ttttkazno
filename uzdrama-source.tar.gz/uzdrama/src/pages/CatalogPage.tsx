import { useState, useMemo } from "react";
import type { Drama } from "../types";
import { CATEGORIES, GENRES } from "../types";
import { PosterCard } from "../components/PosterCard";

export function CatalogPage({
  dramas,
  onSelect,
  favorites,
  toggleFav,
  category,
  search,
}: {
  dramas: Drama[];
  onSelect: (d: Drama) => void;
  favorites: Set<number>;
  toggleFav: (id: number) => void;
  category: string;
  search: string;
}) {
  const [genre, setGenre] = useState("Barchasi");
  const [sort, setSort] = useState("rating");

  const filtered = useMemo(() => {
    let list = dramas;
    if (category !== "all") list = list.filter((d) => d.category === category);
    if (genre !== "Barchasi") list = list.filter((d) => d.genre.includes(genre));
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.originalTitle.toLowerCase().includes(q) ||
          d.cast.some((c) => c.toLowerCase().includes(q))
      );
    }
    if (sort === "rating") list = [...list].sort((a, b) => b.rating - a.rating);
    if (sort === "year") list = [...list].sort((a, b) => b.year - a.year);
    if (sort === "title")
      list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    return list;
  }, [dramas, category, genre, search, sort]);

  return (
    <div className="container mx-auto px-4 sm:px-8 py-8 fade-in">
      <h1 className="text-3xl sm:text-4xl font-black text-white mb-6">
        {category === "all"
          ? "Katalog"
          : CATEGORIES.find((c) => c.id === category)?.label}
      </h1>

      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide flex-1 min-w-0">
          {GENRES.map((g) => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
                genre === g
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-600/30"
                  : "bg-white/10 text-white/80 hover:bg-white/20"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:outline-none focus:border-purple-500"
        >
          <option value="rating">Reyting boʻyicha</option>
          <option value="year">Yil boʻyicha</option>
          <option value="title">Nomi boʻyicha</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-white/60 text-lg">Hech narsa topilmadi</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {filtered.map((d) => (
            <PosterCard
              key={d.id}
              drama={d}
              onClick={() => onSelect(d)}
              onToggleFav={(e) => {
                e.stopPropagation();
                toggleFav(d.id);
              }}
              isFav={favorites.has(d.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
