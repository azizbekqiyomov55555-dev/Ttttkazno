import type { Drama, WatchEntry } from "../types";
import { ClockIcon } from "../components/Icons";

export function HistoryPage({
  dramas,
  history,
  onSelect,
  onClear,
}: {
  dramas: Drama[];
  history: WatchEntry[];
  onSelect: (d: Drama) => void;
  onClear: () => void;
}) {
  const items = history
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .map((h) => ({ entry: h, drama: dramas.find((d) => d.id === h.dramaId) }))
    .filter((x): x is { entry: WatchEntry; drama: Drama } => !!x.drama);

  return (
    <div className="container mx-auto px-4 sm:px-8 py-8 fade-in">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-3xl sm:text-4xl font-black text-white flex items-center gap-3">
          <ClockIcon className="w-8 h-8 text-purple-400" />
          Koʻrish tarixi
        </h1>
        {items.length > 0 && (
          <button
            onClick={onClear}
            className="bg-white/10 hover:bg-white/20 text-white font-bold px-4 py-2 rounded-lg text-sm"
          >
            Tarixni tozalash
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="text-center py-20">
          <ClockIcon className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <p className="text-white/60 text-lg">Hali hech narsa koʻrmagansiz</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map(({ entry, drama }) => (
            <div
              key={drama.id}
              onClick={() => onSelect(drama)}
              className="bg-white/5 hover:bg-white/10 rounded-xl p-3 cursor-pointer transition-colors flex items-center gap-4"
            >
              <div
                className={`w-16 h-24 sm:w-20 sm:h-28 rounded-lg bg-gradient-to-br ${drama.poster} relative overflow-hidden flex-shrink-0`}
              >
                {drama.posterUrl && (
                  <img
                    src={drama.posterUrl}
                    alt=""
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-bold truncate">{drama.title}</h3>
                <p className="text-white/60 text-sm">
                  {drama.episodes === 1
                    ? "Toʻliq film"
                    : `${entry.episode}-qism`}
                </p>
                <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                    style={{
                      width: `${Math.min(100, Math.max(2, entry.progress * 100))}%`,
                    }}
                  />
                </div>
                <p className="text-white/40 text-xs mt-1">
                  {new Date(entry.updatedAt).toLocaleString("uz-UZ")}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
