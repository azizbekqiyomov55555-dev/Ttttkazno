import type { Drama } from "../types";
import { PosterCard } from "../components/PosterCard";
import { HeartIcon } from "../components/Icons";

export function FavoritesPage({
  dramas,
  favorites,
  toggleFav,
  onSelect,
}: {
  dramas: Drama[];
  favorites: Set<number>;
  toggleFav: (id: number) => void;
  onSelect: (d: Drama) => void;
}) {
  const favList = dramas.filter((d) => favorites.has(d.id));

  return (
    <div className="container mx-auto px-4 sm:px-8 py-8 fade-in">
      <h1 className="text-3xl sm:text-4xl font-black text-white mb-6 flex items-center gap-3">
        <HeartIcon filled className="w-8 h-8 text-rose-500" />
        Saqlanganlar
      </h1>
      {favList.length === 0 ? (
        <div className="text-center py-20">
          <HeartIcon className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <p className="text-white/60 text-lg">
            Sevimlilaringiz hozircha boʻsh
          </p>
          <p className="text-white/40 text-sm mt-2">
            Yoqtirgan kontentingizni yurakcha tugmasi orqali saqlang
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {favList.map((d) => (
            <PosterCard
              key={d.id}
              drama={d}
              onClick={() => onSelect(d)}
              onToggleFav={(e) => {
                e.stopPropagation();
                toggleFav(d.id);
              }}
              isFav={true}
            />
          ))}
        </div>
      )}
    </div>
  );
}
