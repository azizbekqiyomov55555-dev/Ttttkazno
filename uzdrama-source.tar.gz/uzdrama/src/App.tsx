import { useState } from "react";
import type { Drama, View } from "./types";
import { useUzDramaState } from "./hooks/useUzDramaState";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { HomePage } from "./pages/HomePage";
import { CatalogPage } from "./pages/CatalogPage";
import { FavoritesPage } from "./pages/FavoritesPage";
import { HistoryPage } from "./pages/HistoryPage";
import { DramaDetailPage } from "./pages/DramaDetailPage";
import { AdminPage } from "./pages/AdminPage";
import { AdminLoginPage } from "./pages/AdminLoginPage";

export default function App() {
  const [view, setView] = useState<View>("home");
  const [selected, setSelected] = useState<Drama | null>(null);
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const {
    dramas,
    setDramas,
    favorites,
    toggleFav,
    reviews,
    addReview,
    deleteReview,
    history,
    recordWatch,
    clearHistory,
    profile,
  } = useUzDramaState();

  const goHome = () => {
    setView("home");
    setMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const goCatalog = (cat: string) => {
    setCategory(cat);
    setView("catalog");
    setMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const goFavorites = () => {
    setView("favorites");
    setMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const goHistory = () => {
    setView("history");
    setMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const openAdmin = () => {
    setMenuOpen(false);
    setView(isAdmin ? "admin" : "admin-login");
    window.scrollTo(0, 0);
  };

  const selectDrama = (d: Drama) => {
    setSelected(d);
    setView("detail");
    window.scrollTo(0, 0);
  };

  const related = selected
    ? dramas
        .filter(
          (d) =>
            d.id !== selected.id &&
            d.genre.some((g) => selected.genre.includes(g))
        )
        .slice(0, 10)
    : [];

  const dramaReviews = selected
    ? reviews.filter((r) => r.dramaId === selected.id)
    : [];

  return (
    <div className="min-h-screen bg-[hsl(222_47%_6%)]">
      <Header
        view={view}
        category={category}
        search={search}
        setSearch={setSearch}
        showSearch={showSearch}
        setShowSearch={setShowSearch}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
        goHome={goHome}
        goCatalog={goCatalog}
        goFavorites={goFavorites}
        goHistory={goHistory}
        openAdmin={openAdmin}
      />

      <main className="pt-14">
        {view === "home" && (
          <HomePage
            dramas={dramas}
            history={history}
            favorites={favorites}
            toggleFav={toggleFav}
            onSelect={selectDrama}
          />
        )}

        {view === "catalog" && (
          <CatalogPage
            dramas={dramas}
            onSelect={selectDrama}
            favorites={favorites}
            toggleFav={toggleFav}
            category={category}
            search={search}
          />
        )}

        {view === "favorites" && (
          <FavoritesPage
            dramas={dramas}
            favorites={favorites}
            toggleFav={toggleFav}
            onSelect={selectDrama}
          />
        )}

        {view === "history" && (
          <HistoryPage
            dramas={dramas}
            history={history}
            onSelect={selectDrama}
            onClear={clearHistory}
          />
        )}

        {view === "detail" && selected && (
          <DramaDetailPage
            drama={selected}
            onBack={goHome}
            favorites={favorites}
            toggleFav={toggleFav}
            onSelect={selectDrama}
            related={related}
            reviews={dramaReviews}
            currentUser={profile.name}
            onAddReview={(rating, text) =>
              addReview(selected.id, rating, text)
            }
            onDeleteReview={deleteReview}
            onWatch={(ep, progress) => recordWatch(selected.id, ep, progress)}
          />
        )}

        {view === "admin-login" && (
          <AdminLoginPage
            onLogin={() => {
              setIsAdmin(true);
              setView("admin");
            }}
            onCancel={goHome}
          />
        )}

        {view === "admin" && isAdmin && (
          <AdminPage
            dramas={dramas}
            setDramas={setDramas}
            onExit={() => {
              setIsAdmin(false);
              goHome();
            }}
          />
        )}
      </main>

      <Footer />
    </div>
  );
}
