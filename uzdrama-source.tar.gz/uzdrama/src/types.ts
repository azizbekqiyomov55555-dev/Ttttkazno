export type Drama = {
  id: number;
  title: string;
  originalTitle: string;
  year: number;
  country: string;
  genre: string[];
  rating: number;
  episodes: number;
  status: "Tugagan" | "Davom etmoqda";
  description: string;
  cast: string[];
  director: string;
  poster: string;
  backdrop: string;
  category: "drama" | "film" | "anime" | "shou";
  featured?: boolean;
  videoUrl?: string;
  posterUrl?: string;
  trailerUrl?: string;
  views?: number;
};

export type Review = {
  id: string;
  dramaId: number;
  user: string;
  rating: number;
  text: string;
  createdAt: number;
};

export type WatchEntry = {
  dramaId: number;
  episode: number;
  progress: number;
  updatedAt: number;
};

export type View =
  | "home"
  | "catalog"
  | "favorites"
  | "detail"
  | "admin"
  | "admin-login"
  | "history";

export const ADMIN_PASSWORD = "admin123";
export const STORAGE_KEY = "uzdrama-content-v1";
export const FAVS_KEY = "uzdrama-favs";
export const REVIEWS_KEY = "uzdrama-reviews-v1";
export const HISTORY_KEY = "uzdrama-history-v1";
export const PROFILE_KEY = "uzdrama-profile-v1";

export const POSTER_GRADIENTS = [
  "from-purple-600 via-pink-500 to-orange-400",
  "from-blue-600 via-cyan-500 to-teal-400",
  "from-rose-600 via-red-500 to-amber-400",
  "from-emerald-600 via-green-500 to-lime-400",
  "from-indigo-600 via-purple-500 to-pink-400",
  "from-fuchsia-600 via-purple-500 to-blue-400",
  "from-amber-600 via-orange-500 to-red-400",
  "from-sky-600 via-blue-500 to-indigo-400",
  "from-pink-600 via-rose-500 to-red-400",
  "from-violet-600 via-fuchsia-500 to-pink-400",
  "from-teal-600 via-emerald-500 to-green-400",
  "from-yellow-500 via-orange-500 to-rose-500",
];

export const CATEGORIES = [
  { id: "all", label: "Barchasi" },
  { id: "drama", label: "Dramalar" },
  { id: "film", label: "Filmlar" },
  { id: "anime", label: "Anime" },
  { id: "shou", label: "Shoular" },
];

export const GENRES = [
  "Barchasi",
  "Romantik",
  "Drama",
  "Komediya",
  "Triller",
  "Jangari",
  "Fantastika",
  "Anime",
  "Tarixiy",
  "Sirli",
  "Qoʻrqinchli",
];
