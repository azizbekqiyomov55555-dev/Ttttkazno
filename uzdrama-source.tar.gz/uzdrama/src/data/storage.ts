import type { Drama, Review, WatchEntry } from "../types";
import {
  STORAGE_KEY,
  FAVS_KEY,
  REVIEWS_KEY,
  HISTORY_KEY,
  PROFILE_KEY,
} from "../types";
import { SEED_DRAMAS } from "./seed";

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

export const storage = {
  loadDramas: (): Drama[] => load<Drama[]>(STORAGE_KEY, SEED_DRAMAS),
  saveDramas: (dramas: Drama[]) => save(STORAGE_KEY, dramas),

  loadFavs: (): number[] => load<number[]>(FAVS_KEY, []),
  saveFavs: (ids: number[]) => save(FAVS_KEY, ids),

  loadReviews: (): Review[] => load<Review[]>(REVIEWS_KEY, []),
  saveReviews: (r: Review[]) => save(REVIEWS_KEY, r),

  loadHistory: (): WatchEntry[] => load<WatchEntry[]>(HISTORY_KEY, []),
  saveHistory: (h: WatchEntry[]) => save(HISTORY_KEY, h),

  loadProfile: (): { name: string } =>
    load<{ name: string }>(PROFILE_KEY, { name: "Mehmon" }),
  saveProfile: (p: { name: string }) => save(PROFILE_KEY, p),
};

export function exportAll() {
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    dramas: storage.loadDramas(),
    favs: storage.loadFavs(),
    reviews: storage.loadReviews(),
    history: storage.loadHistory(),
    profile: storage.loadProfile(),
  };
}

export function importAll(data: ReturnType<typeof exportAll>) {
  if (data.dramas) storage.saveDramas(data.dramas);
  if (data.favs) storage.saveFavs(data.favs);
  if (data.reviews) storage.saveReviews(data.reviews);
  if (data.history) storage.saveHistory(data.history);
  if (data.profile) storage.saveProfile(data.profile);
}
