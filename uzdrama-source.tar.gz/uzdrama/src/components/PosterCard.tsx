import type { Drama } from "../types";
import { StarIcon, PlayIcon, HeartIcon } from "./Icons";

export function PosterCard({
  drama,
  onClick,
  onToggleFav,
  isFav,
  rank,
}: {
  drama: Drama;
  onClick: () => void;
  onToggleFav: (e: React.MouseEvent) => void;
  isFav: boolean;
  rank?: number;
}) {
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer flex-shrink-0 w-[160px] sm:w-[180px] md:w-[200px] transition-transform hover:scale-105 fade-in relative"
    >
      {rank !== undefined && (
        <div
          className="absolute -left-3 -top-2 z-20 text-[80px] sm:text-[100px] font-black leading-none pointer-events-none select-none"
          style={{
            WebkitTextStroke: "2px white",
            color: "transparent",
            textShadow: "0 4px 18px rgba(168,85,247,0.45)",
          }}
        >
          {rank}
        </div>
      )}
      <div
        className={`relative aspect-[2/3] rounded-xl overflow-hidden bg-gradient-to-br ${drama.poster} shadow-lg ring-1 ring-white/5`}
      >
        {drama.posterUrl && (
          <img
            src={drama.posterUrl}
            alt={drama.title}
            className="absolute inset-0 w-full h-full object-cover"
            loading="lazy"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
        <div className="absolute top-2 right-2 flex gap-1">
          <button
            onClick={onToggleFav}
            className="bg-black/50 backdrop-blur-sm p-1.5 rounded-full hover:bg-black/70 transition-colors"
          >
            <HeartIcon
              filled={isFav}
              className={`w-4 h-4 ${isFav ? "text-rose-500" : "text-white"}`}
            />
          </button>
        </div>
        <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm rounded-md px-1.5 py-0.5 flex items-center gap-1">
          <StarIcon className="w-3 h-3 text-yellow-400" />
          <span className="text-xs font-bold text-white">{drama.rating}</span>
        </div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
          <div className="bg-white/20 backdrop-blur-md rounded-full p-4 ring-2 ring-white/40">
            <PlayIcon className="w-8 h-8 text-white" />
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="text-white font-bold text-sm leading-tight line-clamp-2">
            {drama.title}
          </h3>
          <p className="text-white/70 text-xs mt-0.5">
            {drama.year} • {drama.country}
          </p>
        </div>
      </div>
    </div>
  );
}
