export function Footer() {
  return (
    <footer className="border-t border-white/5 mt-12 py-8">
      <div className="container mx-auto px-4 sm:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <span className="text-white font-black text-sm">U</span>
            </div>
            <span className="text-lg font-black shimmer">UzDrama</span>
          </div>
          <p className="text-white/50 text-sm text-center">
            © 2026 UzDrama — Koreys dramalari oʻzbek tilida
          </p>
          <div className="flex gap-4 text-sm text-white/60">
            <a href="#" className="hover:text-white">Biz haqimizda</a>
            <a href="#" className="hover:text-white">Aloqa</a>
            <a href="#" className="hover:text-white">Yordam</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
