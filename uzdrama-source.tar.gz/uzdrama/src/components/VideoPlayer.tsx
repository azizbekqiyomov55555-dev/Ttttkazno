import { useEffect, useRef } from "react";
import type { Drama } from "../types";
import { CloseIcon, PlayIcon } from "./Icons";

export function VideoPlayer({
  drama,
  episode,
  onClose,
  onProgress,
}: {
  drama: Drama;
  episode: number;
  onClose: () => void;
  onProgress: (progress: number) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => {
      if (v.duration > 0) onProgress(v.currentTime / v.duration);
    };
    v.addEventListener("timeupdate", onTime);
    return () => v.removeEventListener("timeupdate", onTime);
  }, [onProgress]);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex items-center justify-center p-4 fade-in"
    >
      <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-white text-xl font-bold">{drama.title}</h3>
            <p className="text-white/60 text-sm">
              {drama.episodes === 1 ? "Toʻliq film" : `${episode}-qism`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="bg-white/10 text-white p-2 rounded-lg hover:bg-white/20"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>
        {drama.videoUrl ? (
          <video
            ref={videoRef}
            src={drama.videoUrl}
            controls
            autoPlay
            className="w-full aspect-video rounded-xl bg-black shadow-2xl"
          />
        ) : (
          <div
            className={`aspect-video rounded-xl overflow-hidden bg-gradient-to-br ${drama.poster} relative flex items-center justify-center`}
          >
            <div className="absolute inset-0 bg-black/50" />
            <div className="relative z-10 text-center px-4">
              <div className="bg-white/20 backdrop-blur-md rounded-full p-6 inline-flex mb-4">
                <PlayIcon className="w-12 h-12 text-white" />
              </div>
              <p className="text-white/90 font-bold text-lg">
                Video hali yuklanmagan
              </p>
              <p className="text-white/60 text-sm mt-2">
                Admin panel orqali video havolasini qoʻshing
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
