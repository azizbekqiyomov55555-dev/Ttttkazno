import type { View } from "../types";
import { CATEGORIES } from "../types";
import { SearchIcon, MenuIcon, CloseIcon } from "./Icons";

export function Header({
  view,
  category,
  search,
  setSearch,
  showSearch,
  setShowSearch,
  menuOpen,
  setMenuOpen,
  goHome,
  goCatalog,
  goFavorites,
  goHistory,
  openAdmin,
}: {
  view: View;
  category: string;
  search: string;
  setSearch: (s: string) => void;
  showSearch: boolean;
  setShowSearch: (b: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (b: boolean) => void;
  goHome: () => void;
  goCatalog: (cat: string) => void;
  goFavorites: () => void;
  goHistory: () => void;
  openAdmin: () => void;
}) {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[hsl(222_47%_6%)]/80 backdrop-blur-lg border-b border-white/5">
      <div className="container mx-auto px-4 sm:px-8 py-3 flex items-center gap-4">
        <button onClick={goHome} className="flex items-center gap-2 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
            <span className="text-white font-black text-sm">U</span>
          </div>
          <span className="text-xl font-black shimmer hidden sm:inline">UzDrama</span>
        </button>

        <nav className="hidden md:flex items-center gap-1 flex-1">
          <button
            onClick={goHome}
            className={`px-3 py-2 rounded-lg font-bold text-sm transition-colors ${
              view === "home" ? "text-white" : "text-white/60 hover:text-white"
            }`}
          >
            Bosh sahifa
          </button>
          {CATEGORIES.slice(1).map((c) => (
            <button
              key={c.id}
              onClick={() => goCatalog(c.id)}
              className={`px-3 py-2 rounded-lg font-bold text-sm transition-colors ${
                view === "catalog" && category === c.id
                  ? "text-white"
                  : "text-white/60 hover:text-white"
              }`}
            >
              {c.label}
            </button>
          ))}
          <button
            onClick={goFavorites}
            className={`px-3 py-2 rounded-lg font-bold text-sm transition-colors ${
              view === "favorites" ? "text-white" : "text-white/60 hover:text-white"
            }`}
          >
            Saqlanganlar
          </button>
          <button
            onClick={goHistory}
            className={`px-3 py-2 rounded-lg font-bold text-sm transition-colors ${
              view === "history" ? "text-white" : "text-white/60 hover:text-white"
            }`}
          >
            Tarix
          </button>
          <button
            onClick={openAdmin}
            className={`px-3 py-2 rounded-lg font-bold text-sm transition-colors ${
              view === "admin" || view === "admin-login"
                ? "text-purple-400"
                : "text-white/60 hover:text-white"
            }`}
          >
            Admin
          </button>
        </nav>

        <div className="flex-1 md:flex-none flex items-center gap-2 justify-end">
          {showSearch ? (
            <div className="relative flex-1 md:w-64 md:flex-none">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
              <input
                autoFocus
                type="text"
                placeholder="Qidirish..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  if (view !== "catalog") goCatalog("all");
                }}
                onBlur={() => {
                  if (!search) setShowSearch(false);
                }}
                className="w-full bg-white/10 text-white pl-9 pr-3 py-2 rounded-lg border border-white/20 focus:outline-none focus:border-purple-500"
              />
            </div>
          ) : (
            <button
              onClick={() => setShowSearch(true)}
              className="p-2 hover:bg-white/10 rounded-lg"
            >
              <SearchIcon className="w-5 h-5 text-white" />
            </button>
          )}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden p-2 hover:bg-white/10 rounded-lg"
          >
            {menuOpen ? (
              <CloseIcon className="w-5 h-5 text-white" />
            ) : (
              <MenuIcon className="w-5 h-5 text-white" />
            )}
          </button>
          <button className="hidden md:flex bg-purple-600 hover:bg-purple-700 text-white font-bold px-4 py-2 rounded-lg text-sm transition-colors shadow-lg shadow-purple-600/30">
            Kirish
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[hsl(222_47%_6%)]">
          <div className="container mx-auto px-4 py-2 flex flex-col">
            <button
              onClick={goHome}
              className="text-left px-3 py-3 text-white font-bold hover:bg-white/5 rounded-lg"
            >
              Bosh sahifa
            </button>
            {CATEGORIES.slice(1).map((c) => (
              <button
                key={c.id}
                onClick={() => goCatalog(c.id)}
                className="text-left px-3 py-3 text-white font-bold hover:bg-white/5 rounded-lg"
              >
                {c.label}
              </button>
            ))}
            <button
              onClick={goFavorites}
              className="text-left px-3 py-3 text-white font-bold hover:bg-white/5 rounded-lg"
            >
              Saqlanganlar
            </button>
            <button
              onClick={goHistory}
              className="text-left px-3 py-3 text-white font-bold hover:bg-white/5 rounded-lg"
            >
              Tarix
            </button>
            <button
              onClick={openAdmin}
              className="text-left px-3 py-3 text-purple-400 font-bold hover:bg-white/5 rounded-lg"
            >
              Admin Panel
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
