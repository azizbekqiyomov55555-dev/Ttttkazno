import { useState } from "react";
import type { Review } from "../types";
import { StarIcon } from "./Icons";

export function ReviewSection({
  reviews,
  currentUser,
  onAdd,
  onDelete,
}: {
  reviews: Review[];
  currentUser: string;
  onAdd: (rating: number, text: string) => void;
  onDelete: (id: string) => void;
}) {
  const [rating, setRating] = useState(10);
  const [text, setText] = useState("");
  const avg =
    reviews.length > 0
      ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
      : "—";

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAdd(rating, text.trim());
    setText("");
    setRating(10);
  };

  return (
    <div className="max-w-3xl mb-12 space-y-4">
      <div className="bg-white/5 rounded-xl p-5 border border-white/10">
        <div className="flex items-center gap-3 mb-3">
          <div className="text-3xl font-black text-yellow-400 flex items-center gap-2">
            <StarIcon className="w-7 h-7" />
            {avg}
          </div>
          <div className="text-white/60 text-sm">
            {reviews.length} ta foydalanuvchi izohi
          </div>
        </div>
      </div>

      <form
        onSubmit={submit}
        className="bg-white/5 rounded-xl p-5 border border-white/10"
      >
        <div className="text-white font-bold mb-2">Sizning izohingiz</div>
        <div className="flex items-center gap-2 mb-3">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setRating(n)}
              className="p-0.5"
            >
              <StarIcon
                className={`w-5 h-5 ${
                  n <= rating ? "text-yellow-400" : "text-white/20"
                }`}
              />
            </button>
          ))}
          <span className="text-white/60 text-sm ml-2">{rating}/10</span>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          placeholder="Fikringizni yozing..."
          className="form-input mb-3"
        />
        <button
          type="submit"
          disabled={!text.trim()}
          className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold px-5 py-2 rounded-lg"
        >
          Izoh qoldirish
        </button>
      </form>

      {reviews
        .slice()
        .sort((a, b) => b.createdAt - a.createdAt)
        .map((c) => (
          <div key={c.id} className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                {c.user[0]?.toUpperCase() || "?"}
              </div>
              <div className="flex-1">
                <p className="text-white font-bold">{c.user}</p>
                <div className="flex items-center gap-1 text-xs">
                  <StarIcon className="w-3 h-3 text-yellow-400" />
                  <span className="text-yellow-400">{c.rating}/10</span>
                  <span className="text-white/40 ml-2">
                    {new Date(c.createdAt).toLocaleDateString("uz-UZ")}
                  </span>
                </div>
              </div>
              {c.user === currentUser && (
                <button
                  onClick={() => onDelete(c.id)}
                  className="text-rose-400 text-xs hover:text-rose-300"
                >
                  Oʻchirish
                </button>
              )}
            </div>
            <p className="text-white/80 text-sm whitespace-pre-wrap">{c.text}</p>
          </div>
        ))}

      {reviews.length === 0 && (
        <div className="text-center text-white/50 py-8">
          Hali izohlar yoʻq. Birinchi boʻling!
        </div>
      )}
    </div>
  );
}
