import type { Drama } from "../types";
import { PosterCard } from "./PosterCard";

export function Row({
  title,
  dramas,
  onSelect,
  favorites,
  toggleFav,
  ranked,
  icon,
}: {
  title: string;
  dramas: Drama[];
  onSelect: (d: Drama) => void;
  favorites: Set<number>;
  toggleFav: (id: number) => void;
  ranked?: boolean;
  icon?: React.ReactNode;
}) {
  if (dramas.length === 0) return null;
  return (
    <section className="py-6">
      <div className="container mx-auto px-4 sm:px-8">
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-4 flex items-center gap-2">
          {icon}
          {title}
        </h2>
      </div>
      <div className="container mx-auto px-4 sm:px-8">
        <div
          className={`flex gap-3 sm:gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-4 sm:-mx-8 px-4 sm:px-8 ${
            ranked ? "pl-8 sm:pl-12" : ""
          }`}
        >
          {dramas.map((d, i) => (
            <PosterCard
              key={d.id}
              drama={d}
              onClick={() => onSelect(d)}
              onToggleFav={(e) => {
                e.stopPropagation();
                toggleFav(d.id);
              }}
              isFav={favorites.has(d.id)}
              rank={ranked ? i + 1 : undefined}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
