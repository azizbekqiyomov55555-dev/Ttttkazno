import type { Drama } from "../types";
import { StarIcon, PlayIcon } from "./Icons";

export function HeroBanner({
  drama,
  onPlay,
  onInfo,
}: {
  drama: Drama;
  onPlay: () => void;
  onInfo: () => void;
}) {
  return (
    <div
      className={`relative h-[65vh] min-h-[440px] w-full overflow-hidden bg-gradient-to-br ${drama.backdrop}`}
    >
      {drama.posterUrl && (
        <img
          src={drama.posterUrl}
          alt={drama.title}
          className="absolute inset-0 w-full h-full object-cover scale-105 animate-[heroZoom_20s_ease-in-out_infinite_alternate]"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[hsl(222_47%_6%)] via-[hsl(222_47%_6%)]/40 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[hsl(222_47%_6%)] via-[hsl(222_47%_6%)]/60 to-transparent" />
      <div className="absolute inset-0 flex items-end pb-12 sm:items-center sm:pb-0">
        <div className="container mx-auto px-4 sm:px-8">
          <div className="max-w-2xl fade-in">
            <span className="inline-flex items-center gap-1.5 bg-purple-600/90 backdrop-blur text-white text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wide mb-3 shadow-lg shadow-purple-600/40">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              Top tavsiya
            </span>
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white mb-3 leading-tight drop-shadow-2xl">
              {drama.title}
            </h1>
            <div className="flex flex-wrap items-center gap-3 mb-4 text-sm text-white/85">
              <div className="flex items-center gap-1">
                <StarIcon className="w-4 h-4 text-yellow-400" />
                <span className="font-bold text-white">{drama.rating}</span>
              </div>
              <span>•</span>
              <span>{drama.year}</span>
              <span>•</span>
              <span>{drama.episodes} qism</span>
              <span>•</span>
              <span className="px-2 py-0.5 border border-white/30 rounded text-xs">
                {drama.country}
              </span>
            </div>
            <p className="text-white/90 text-sm sm:text-base mb-6 line-clamp-3 max-w-xl">
              {drama.description}
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={onPlay}
                className="bg-white text-black font-bold px-6 py-3 rounded-lg flex items-center gap-2 hover:bg-white/90 transition-all hover:scale-105 shadow-xl"
              >
                <PlayIcon className="w-5 h-5" />
                Koʻrish
              </button>
              <button
                onClick={onInfo}
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white font-bold px-6 py-3 rounded-lg hover:bg-white/20 transition-all"
              >
                Batafsil
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
